/*
 * UNIVERSIDAD ICESI
 * ALGORITMOS Y PROGRAMACION II
 * PROYECTO FINAL DEL CURSO
 * SANTIAGO RODAS Y JULIAN ANDRES RIVERA
 * GRUPO BANCARIO
 */

package modelo;

public class Arl extends Seguro{
	
	// ---------------------------------------------------------------------------------------
	
	// METODO CONSTRUCTOR DE LA CLASE ARL QUE HEREDA DE LA CLASE SEGURO

	public Arl(String nombre, String id, String direccion, String estratoEconomico, String email) {
		
		super(nombre, id, direccion, estratoEconomico, email);

	}
	
	// ---------------------------------------------------------------------------------------

}
