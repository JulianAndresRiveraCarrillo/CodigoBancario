/*
 * UNIVERSIDAD ICESI
 * ALGORITMOS Y PROGRAMACION II
 * PROYECTO FINAL DEL CURSO
 * SANTIAGO RODAS Y JULIAN ANDRES RIVERA
 * GRUPO BANCARIO
 */

package modelo;

public class Promocion extends Beneficio {
	
	// ---------------------------------------------------------------------------------------
	
	// METODO CONSTRUCTOR DE LA CLASE PROMOCION QUE HEREDA DE LA CLASE BENEFICIO

	public Promocion(String nombre, String id, String contrasena, int valor) {
		
		super(nombre, id, contrasena, valor);

	}
	
	// ---------------------------------------------------------------------------------------

}
