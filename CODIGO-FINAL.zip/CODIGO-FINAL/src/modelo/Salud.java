/*
 * UNIVERSIDAD ICESI
 * ALGORITMOS Y PROGRAMACION II
 * PROYECTO FINAL DEL CURSO
 * SANTIAGO RODAS Y JULIAN ANDRES RIVERA
 * GRUPO BANCARIO
 */

package modelo;

public class Salud extends Seguro {
	
	// ---------------------------------------------------------------------------------------
	
	// METODO CONSTRUCTOR DE LA CLASE SALUD QUE HEREDA DE LA CLASE SEGURO

	public Salud(String nombre, String id, String direccion, String estratoEconomico, String email) {
		
		super(nombre, id, direccion, estratoEconomico, email);

	}
	
	// ---------------------------------------------------------------------------------------

}
